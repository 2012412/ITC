print ('lecture 11 - file saving using python');


#1. file object/open
File = open ('Classnotes_lecture 11.txt', 'w')
#2. file write 
File.write ('Scientific calculator \numair khan, chandras ayush, erum shehzadi \n Topic: Python');
#3. file close/save